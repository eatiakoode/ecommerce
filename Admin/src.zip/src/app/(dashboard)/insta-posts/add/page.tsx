"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import axios from "axios";

const API_BASE = "http://localhost:5000/api/instapost";

export default function AddInstaPostPage() {
  const [title, setTitle] = useState("");
  const [image, setImage] = useState("");
  const [link, setLink] = useState("");
  const [sku, setSku] = useState("");
  const [skuStatus, setSkuStatus] = useState<null | "available" | "duplicate">(null);
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Check SKU uniqueness
  const checkSku = async (skuValue: string) => {
    if (!skuValue) {
      setSkuStatus(null);
      return;
    }
    try {
      const res = await axios.get(`${API_BASE}?SKU=${skuValue}`);
      if (Array.isArray(res.data) && res.data.length === 0) {
        setSkuStatus("available");
      } else {
        setSkuStatus("duplicate");
      }
    } catch {
      setSkuStatus(null);
    }
  };

  const handleSkuChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSku(value);
    checkSku(value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post(API_BASE, {
        title,
        imageLink: image,
        instaLink: link,
        SKU: sku,
        isActive
      });
      toast.success("Insta post added successfully!");
      setSku("");
      setSkuStatus(null);
      setTitle("");
      setImage("");
      setLink("");
      setIsActive(true);
      router.push("/insta-posts");
    } catch {
      toast.error("Failed to add insta post");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Add Insta Post</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl shadow-md">
        <div>
          <label className="block mb-1 font-medium">Title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Image Link</label>
          <input value={image} onChange={e => setImage(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Instagram Post Link</label>
          <input value={link} onChange={e => setLink(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">SKU</label>
          <input value={sku} onChange={handleSkuChange} required className="border px-3 py-2 rounded w-full" />
          {sku && skuStatus === "available" && (
            <div className="text-green-600 text-sm mt-1">SKU available</div>
          )}
          {sku && skuStatus === "duplicate" && (
            <div className="text-red-600 text-sm mt-1">SKU already exists</div>
          )}
        </div>
        <div>
          <label className="block mb-1 font-medium">Status</label>
          <select value={isActive ? "active" : "inactive"} onChange={e => setIsActive(e.target.value === "active")}
            className="border px-3 py-2 rounded w-full">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <button type="submit" disabled={loading || skuStatus === "duplicate"} className="bg-blue-600 text-white px-4 py-2 rounded font-medium hover:bg-blue-700 transition-colors">
          {loading ? "Adding..." : "Add Insta Post"}
        </button>
      </form>
    </div>
  );
} 