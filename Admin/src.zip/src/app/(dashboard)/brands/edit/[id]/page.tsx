"use client";
import { useEffect, useState } from "react";
import { getBrands, updateBrand } from "@/api/brand";
import { useRouter, useParams } from "next/navigation";
import { toast } from "sonner";

export default function EditBrandPage() {
  const router = useRouter();
  const params = useParams();
  const id = params?.id;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    const fetchBrand = async () => {
      setLoading(true);
      setError("");
      try {
        const brands = await getBrands();
        const brand = brands.find(b => b._id === id);
        if (!brand) throw new Error("Brand not found");
        setName(brand.name);
        setDescription(brand.description);
        setIsActive(brand.isActive);
      } catch (e) {
        setError("Failed to load brand");
      } finally {
        setLoading(false);
      }
    };
    if (id) fetchBrand();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateBrand(id, { name, description, isActive });
      toast.success("Brand updated");
      router.push("/brands");
    } catch (e) {
      toast.error("Failed to update brand");
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;
  if (error) return <div className="p-4 text-red-500">{error}</div>;

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Edit Brand</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input value={name} onChange={e => setName(e.target.value)} required className="border p-2 w-full rounded" />
        </div>
        <div>
          <label className="block mb-1">Description</label>
          <input value={description} onChange={e => setDescription(e.target.value)} className="border p-2 w-full rounded" />
        </div>
        <div className="flex items-center gap-2">
          <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} id="isActive" />
          <label htmlFor="isActive">Active</label>
        </div>
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded">
          {loading ? "Updating..." : "Update Brand"}
        </button>
      </form>
    </div>
  );
} 