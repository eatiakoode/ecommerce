"use client";
import { useEffect, useState } from "react";
import BrandsTable from "./_components/brands-table";
import { getBrands } from "@/api/brand";
import { toast } from "sonner";

// Define Brand type inline for this file
interface Brand {
  _id: string;
  name: string;
  description: string;
  isActive: boolean;
}

export default function BrandsPage() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const fetchBrands = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getBrands();
      setBrands(data);
    } catch (e) {
      setError("Failed to load brands");
      toast.error("Failed to load brands");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBrands();
  }, []);

  // Filter brands by title and status
  const filteredBrands = brands.filter(b => {
    const nameMatch = (b.title || "").toLowerCase().includes(filter.toLowerCase());
    const statusMatch = statusFilter === "all" || (statusFilter === "active" && b.isActive) || (statusFilter === "inactive" && !b.isActive);
    return nameMatch && statusMatch;
  });

  return (
    <div className="p-4">
      <BrandsTable
        brands={filteredBrands}
        loading={loading}
        error={error}
        onRefresh={fetchBrands}
        setFilter={setFilter}
        filter={filter}
        setBrands={setBrands}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
      />
    </div>
  );
}
