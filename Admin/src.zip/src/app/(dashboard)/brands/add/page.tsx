"use client";
import { useState } from "react";
import { addBrand } from "@/api/brand";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function AddBrandPage() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addBrand({ name, description, isActive });
      toast.success("Brand added");
      router.push("/brands");
    } catch (e) {
      toast.error("Failed to add brand");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Add Brand</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input value={name} onChange={e => setName(e.target.value)} required className="border p-2 w-full rounded" />
        </div>
        <div>
          <label className="block mb-1">Description</label>
          <input value={description} onChange={e => setDescription(e.target.value)} className="border p-2 w-full rounded" />
        </div>
        <div className="flex items-center gap-2">
          <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} id="isActive" />
          <label htmlFor="isActive">Active</label>
        </div>
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded">
          {loading ? "Adding..." : "Add Brand"}
        </button>
      </form>
    </div>
  );
} 