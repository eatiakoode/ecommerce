import Filters from "./filters";
import Actions from "./actions";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, Dispatch, SetStateAction } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import axios from "axios";
import { Download, Upload } from "lucide-react";

interface BrandsTableProps {
  brands: any[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  setBrands: Dispatch<SetStateAction<any[]>>;
  setFilter: Dispatch<SetStateAction<string>>;
  filter: string;
  statusFilter: string;
  setStatusFilter: Dispatch<SetStateAction<string>>;
}

export default function BrandsTable({ brands, loading, error, onRefresh, setBrands, setFilter, filter, statusFilter, setStatusFilter }: BrandsTableProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const router = useRouter();

  // Export logic (mock)
  const handleExport = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/brand/export", { responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "brands_export.csv");
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch {
      toast.error("Failed to export brands");
    }
  };

  // Import logic (mock)
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    toast.success("Brands imported (mock)");
    e.target.value = "";
  };

  // Bulk Action logic (placeholder)
  const handleBulkAction = () => {
    toast.info("Bulk action (placeholder)");
  };

  // Bulk Delete logic
  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm("Are you sure you want to delete the selected brands?")) return;
    setBrands((prev: any[]) => prev.filter((b: any) => !selectedIds.includes(b._id)));
    setSelectedIds([]);
    onRefresh();
    toast.success("Selected brands deleted!");
  };

  // Handle select all
  const allSelected = brands.length > 0 && selectedIds.length === brands.length;
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(brands.map(b => b._id));
    } else {
      setSelectedIds([]);
    }
  };
  // Handle single select
  const handleSelect = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds(prev => [...prev, id]);
    } else {
      setSelectedIds(prev => prev.filter(_id => _id !== id));
    }
  };

  if (loading) return <Skeleton className="h-40 w-full" />;
  if (error) return <div className="text-red-500">{error}</div>;

  return (
    <div className="space-y-8">
      {/* Actions Bar Card (Export, Import, Bulk Action, Delete, Add Brand) */}
      <div className="bg-background rounded-xl shadow-md p-6 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div className="flex gap-3">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 border border-gray-300 bg-white text-gray-700 px-5 py-2 rounded-md hover:bg-blue-100 hover:text-blue-700 hover:border-blue-200 transition-colors text-sm font-medium min-w-[110px]"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
          <label className="flex items-center gap-2 border border-gray-300 bg-white text-gray-700 px-5 py-2 rounded-md cursor-pointer text-sm font-medium hover:bg-green-100 transition-colors min-w-[110px]">
            <Upload className="w-4 h-4" />
            Import
            <input type="file" hidden onChange={handleImport} />
          </label>
        </div>
        <div className="flex gap-3 md:ml-auto justify-end w-full">
          {/* <button
            onClick={handleBulkAction}
            className="flex items-center gap-2 bg-[#232B39] text-white px-5 py-2 rounded-md hover:bg-[#2C3648] transition-colors text-sm font-medium min-w-[120px]"
          >
            Bulk Action
          </button>
          <button
            onClick={handleBulkDelete}
            disabled={selectedIds.length === 0}
            className="flex items-center gap-2 bg-[#7B2323] text-white px-5 py-2 rounded-md hover:bg-[#A93226] transition-colors text-sm font-medium min-w-[90px] disabled:opacity-50"
          >
            Delete
          </button> */}
          <button
            onClick={() => router.push("/brands/add")}
            className="flex items-center gap-2 bg-[#2563eb] text-white px-5 py-2 rounded-md hover:bg-[#1d4ed8] transition-colors text-sm font-medium min-w-[120px]"
          >
            + Add Brand
          </button>
        </div>
      </div>
      {/* Filter Bar Card (search, sort/status, filter, reset) */}
      <div className="bg-background rounded-xl shadow-md p-6 flex flex-col md:flex-row gap-4 w-full">
        <input
          type="text"
          placeholder="Search brand..."
          value={filter}
          onChange={e => setFilter(e.target.value)}
          className="rounded-lg border border-border px-4 py-3 w-full md:w-1/3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500 bg-background"
        />
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="rounded-lg border border-border px-4 py-3 w-full md:w-1/4 text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500 bg-background"
        >
          <option value="all">Sort/Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
        <button
          type="button"
          className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
        >
          Filter
        </button>
        <button
          type="button"
          onClick={() => { setFilter(""); setStatusFilter("all"); }}
          className="bg-muted text-foreground px-8 py-3 rounded-lg font-medium hover:bg-muted/70 transition-colors border border-border"
        >
          Reset
        </button>
      </div>
      {/* Brands Table Card */}
      <div className="bg-background rounded-xl shadow-md p-6 overflow-x-auto">
        <table className="min-w-full border-separate border-spacing-0">
          <thead>
            <tr className="bg-muted">
              <th className="p-3 border-b border-border text-left font-bold uppercase text-xs w-10 align-middle text-foreground">
                <input
                  type="checkbox"
                  checked={brands.length > 0 && selectedIds.length === brands.length}
                  onChange={e => setSelectedIds(e.target.checked ? brands.map(b => b._id) : [])}
                  className="accent-blue-600 w-4 h-4 align-middle"
                />
              </th>
              <th className="p-3 border-b border-border text-left font-bold uppercase text-xs align-middle text-foreground">Name</th>
              <th className="p-3 border-b border-border text-left font-bold uppercase text-xs align-middle text-foreground">Description</th>
              <th className="p-3 border-b border-border text-left font-bold uppercase text-xs align-middle text-foreground">Status</th>
              <th className="p-3 border-b border-border text-left font-bold uppercase text-xs align-middle text-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {brands.length === 0 ? (
              <tr className="bg-background">
                <td colSpan={5} className="text-center p-4 text-foreground">No brands found.</td>
              </tr>
            ) : (
              brands.map((brand) => (
                <tr key={brand._id} className="bg-background transition-colors hover:bg-muted/70">
                  <td className="p-3 border-b border-border align-middle">
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(brand._id)}
                      onChange={e => setSelectedIds(e.target.checked ? [...selectedIds, brand._id] : selectedIds.filter(id => id !== brand._id))}
                      className="accent-blue-600 w-4 h-4 align-middle"
                    />
                  </td>
                  <td className="p-3 border-b border-border text-foreground align-middle">{brand.name}</td>
                  <td className="p-3 border-b border-border text-foreground align-middle">{brand.description}</td>
                  <td className="p-3 border-b border-border text-foreground align-middle">
                    <span className={`px-4 py-1 rounded-full text-xs font-semibold ${brand.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{brand.isActive ? 'Active' : 'Inactive'}</span>
                  </td>
                  <td className="p-3 border-b border-border align-middle">
                    <Actions brand={brand} onRefresh={onRefresh} setBrands={setBrands} />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
} 