"use client";
import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";

// Mock data for demonstration (should be replaced with API call in future)
const mockSliders = [
  { _id: "1", title: "Summer Sale", image: "/slider1.jpg", description: "Up to 50% off!", isActive: true },
  { _id: "2", title: "Winter Collection", image: "/slider2.jpg", description: "New arrivals for winter.", isActive: false },
];

export default function EditSliderPage() {
  const router = useRouter();
  const params = useParams();
  const id = params?.id as string;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");

  useEffect(() => {
    setLoading(true);
    // In a real app, fetch from API
    const slider = mockSliders.find(s => s._id === id);
    if (!slider) {
      setError("Slider not found");
      setLoading(false);
      return;
    }
    setTitle(slider.title);
    setDescription(slider.description);
    setImage(slider.image);
    setLoading(false);
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // In a real app, call API to update slider
    setTimeout(() => {
      setLoading(false);
      alert("Slider updated (mock)");
      router.push("/sliders");
    }, 500);
  };

  if (loading) return <div className="p-4">Loading...</div>;
  if (error) return <div className="p-4 text-red-500">{error}</div>;

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Edit Slider</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl shadow-md">
        <div>
          <label className="block mb-1 font-medium">Title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Description</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Image Link</label>
          <input value={image} onChange={e => setImage(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded font-medium hover:bg-blue-700 transition-colors">
          {loading ? "Updating..." : "Update Slider"}
        </button>
      </form>
    </div>
  );
} 