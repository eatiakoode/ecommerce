"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AddSliderPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // In a real app, call API to add slider
    setTimeout(() => {
      setLoading(false);
      alert("Slider added (mock)");
      router.push("/sliders");
    }, 500);
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Add Slider</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl shadow-md">
        <div>
          <label className="block mb-1 font-medium">Title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Description</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <div>
          <label className="block mb-1 font-medium">Image Link</label>
          <input value={image} onChange={e => setImage(e.target.value)} required className="border px-3 py-2 rounded w-full" />
        </div>
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded font-medium hover:bg-blue-700 transition-colors">
          {loading ? "Adding..." : "Add Slider"}
        </button>
      </form>
    </div>
  );
} 