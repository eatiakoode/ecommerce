// app/(admin)/products/add/AddProductForm.tsx
"use client";

import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Product } from "@/types";
import axios from "axios";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

type Option = {
  _id: string;
  name: string;
};

export default function AddProductForm() {
  const router = useRouter();

  const [colors, setColors] = useState<Option[]>([]);
  const [sizes, setSizes] = useState<Option[]>([]);
  const [categories, setCategories] = useState<Option[]>([]);
  const [images, setImages] = useState<File[]>([]);

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { isSubmitting },
  } = useForm();

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [colorRes, sizeRes, categoryRes] = await Promise.all([
          axios.get("/api/colors"),
          axios.get("/api/sizes"),
          axios.get("/api/categories"),
        ]);
        setColors(colorRes.data);
        setSizes(sizeRes.data);
        setCategories(categoryRes.data);
      } catch (err) {
        toast.error("Failed to load options");
      }
    };
    fetchOptions();
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setImages([...e.target.files]);
    }
  };

  const onSubmit = async (data: any) => {
    try {
      const formData = new FormData();
      images.forEach((img) => formData.append("images", img));
      Object.keys(data).forEach((key) => {
        const value = data[key];
        if (Array.isArray(value)) {
          value.forEach((v: string) => formData.append(key, v));
        } else {
          formData.append(key, value);
        }
      });

      await axios.post("/api/products", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast.success("Product added successfully");
      router.push("/admin/products");
      reset();
    } catch (err) {
      toast.error("Failed to add product");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 max-w-2xl mx-auto p-4">
      <Input {...register("title", { required: true })} placeholder="Title" />
      <Input {...register("slug")} placeholder="Slug (auto or custom)" />
      <Input {...register("brand")} placeholder="Brand" />
      <Input type="number" {...register("mrp", { required: true })} placeholder="MRP" />
      <Input type="number" {...register("salePrice")} placeholder="Sale Price" />
      <Input type="number" {...register("quantity")} placeholder="Stock Quantity" />
      <Textarea {...register("shortDesc")} placeholder="Short Description" />
      <Textarea {...register("longDesc")} placeholder="Long Description" />

      {/* Image Upload */}
      <div>
        <label>Product Images</label>
        <Input type="file" multiple accept="image/*" onChange={handleImageChange} />
        <div className="flex flex-wrap mt-2 gap-2">
          {images.map((img, i) => (
            <p key={i} className="text-xs text-gray-500">
              {img.name}
            </p>
          ))}
        </div>
      </div>

      {/* Multi-selects */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label>Colors</label>
          <Controller
            control={control}
            name="colors"
            render={({ field }) => (
              <select multiple {...field} className="w-full border rounded px-2 py-1">
                {colors.map((color) => (
                  <option key={color._id} value={color._id}>
                    {color.name}
                  </option>
                ))}
              </select>
            )}
          />
        </div>
        <div>
          <label>Sizes</label>
          <Controller
            control={control}
            name="sizes"
            render={({ field }) => (
              <select multiple {...field} className="w-full border rounded px-2 py-1">
                {sizes.map((size) => (
                  <option key={size._id} value={size._id}>
                    {size.name}
                  </option>
                ))}
              </select>
            )}
          />
        </div>
        <div className="col-span-2">
          <label>Category</label>
          <Controller
            control={control}
            name="category"
            render={({ field }) => (
              <select {...field} className="w-full border rounded px-2 py-1">
                <option value="">Select category</option>
                {categories.map((cat) => (
                  <option key={cat._id} value={cat._id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            )}
          />
        </div>
      </div>

      <Button type="submit" disabled={isSubmitting} className="mt-4">
        {isSubmitting ? "Submitting..." : "Add Product"}
      </Button>
    </form>
  );
}
