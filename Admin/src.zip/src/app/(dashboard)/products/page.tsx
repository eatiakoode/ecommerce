// src/app/(dashboard)/products/page.tsx
"use client";

import { useState, useMemo } from "react";
import ProductFilters from "./_components/ProductFilters";
import ProductActions from "./_components/ProductActions";
import AllProducts from "./_components/products-table";
import { useProducts } from "@/hooks/useProducts";

export default function ProductPage() {
  const [filters, setFilters] = useState({
    search: "",
    category: "",
    sort: "",
  });

  const { data: products, isLoading, error } = useProducts();

  // Filter products on the client side
  const filteredProducts = useMemo(() => {
    if (!products) return [];

    let filtered = [...products];

    // Search filter
    if (filters.search) {
      filtered = filtered.filter((product) =>
        product.title?.toLowerCase().includes(filters.search.toLowerCase()) ||
        product.description?.toLowerCase().includes(filters.search.toLowerCase()) ||
        product.brand?.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    // Category filter
    if (filters.category) {
      filtered = filtered.filter((product) =>
        product.category?.toLowerCase() === filters.category.toLowerCase()
      );
    }

    // Sort filter
    if (filters.sort) {
      switch (filters.sort) {
        case "low":
          filtered.sort((a, b) => a.price - b.price);
          break;
        case "high":
          filtered.sort((a, b) => b.price - a.price);
          break;
        case "published":
          filtered = filtered.filter((product) => product.published === true);
          break;
        case "unpublished":
          filtered = filtered.filter((product) => product.published === false);
          break;
        case "status-selling":
          filtered = filtered.filter((product) => product.quantity > 0);
          break;
        case "status-out-of-stock":
          filtered = filtered.filter((product) => product.quantity <= 0);
          break;
        case "date-added-asc":
          filtered.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
          break;
        case "date-added-desc":
          filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          break;
        case "date-updated-asc":
          filtered.sort((a, b) => new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime());
          break;
        case "date-updated-desc":
          filtered.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
          break;
        default:
          break;
      }
    }

    return filtered;
  }, [products, filters]);

  if (isLoading) return <div>Loading products...</div>;
  if (error) return <div>Error loading products</div>;

  return (
    <div className="space-y-6">
      <ProductActions />
      <ProductFilters onFilterChange={setFilters} />
      <AllProducts products={filteredProducts} />
    </div>
  );
}
