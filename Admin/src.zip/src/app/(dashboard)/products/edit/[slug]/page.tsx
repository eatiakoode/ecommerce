import { notFound } from "next/navigation";
import { useProduct } from "@/hooks/useProducts";

export default async function EditProductPage({ params }: { params: { slug: string } }) {
  // TODO: Replaced mock data with real API call using useProduct
  const product = await useProduct(params.slug);

  if (!product) {
    notFound();
  }

  return (
    <div className="max-w-3xl mx-auto py-8">
      <EditProduct product={product} />
    </div>
  );
} 