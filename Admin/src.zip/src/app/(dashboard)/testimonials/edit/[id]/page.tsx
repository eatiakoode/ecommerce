"use client";
import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import axios from "axios";

const API_BASE = "http://localhost:5000/api/testimonials";

export default function EditTestimonialPage() {
  const router = useRouter();
  const { id } = useParams(); // Correct way to get id
  console.log("Edit page id:", id); // Debug
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ title: "", description: "", image: "", status: "active" });

  useEffect(() => {
    const fetchTestimonial = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await axios.get(`${API_BASE}/${id}`);
        const t = res.data;
        setForm({
          title: t.title || "",
          description: t.description || "",
          image: t.image || "",
          status: t.status || "active",
        });
      } catch (e) {
        setError("Failed to load testimonial");
      } finally {
        setLoading(false);
      }
    };
    if (id) fetchTestimonial();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.put(`${API_BASE}/${id}`, form);
      router.push("/testimonials");
    } catch (e) {
      setError("Failed to update testimonial");
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;
  if (error) return <div className="p-4 text-red-500">{error}</div>;

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Edit Testimonial</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Title</label>
          <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required className="border p-2 w-full rounded" />
        </div>
        <div>
          <label className="block mb-1">Description</label>
          <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} required className="border p-2 w-full rounded" />
        </div>
        <div>
          <label className="block mb-1">Image Link</label>
          <input value={form.image} onChange={e => setForm(f => ({ ...f, image: e.target.value }))} required className="border p-2 w-full rounded" />
        </div>
        <div>
          <label className="block mb-1">Status</label>
          <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))} required className="border p-2 w-full rounded">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded">
          {loading ? "Saving..." : "Save Changes"}
        </button>
      </form>
    </div>
  );
} 