import axios from "axios";

const API_BASE = "http://localhost:5000/api/brand";

export async function getBrands() {
  const res = await axios.get(API_BASE);
  return res.data;
}

export async function addBrand(data: any) {
  const res = await axios.post(API_BASE, data);
  return res.data;
}

export async function updateBrand(id: string, data: any) {
  const res = await axios.put(`${API_BASE}/${id}`, data);
  return res.data;
}

export async function deleteBrand(id: string) {
  const res = await axios.delete(`${API_BASE}/${id}`);
  return res.data;
}

// The importBrands and exportBrands can remain as is or be updated if you have endpoints for them.
export async function importBrands(file: any) {
  // TODO: Implement if backend supports
  return true;
}

export async function exportBrands() {
  // TODO: Implement if backend supports
  return true;
} 