const asyncHandler = require("express-async-handler");
const Product = require("../../models/productModel");

const getProducts = asyncHandler(async (req, res) => {
  try {
    const products = await Product.find({})
      .select("title price images")
      .limit(3);

    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch products", error });
  }
});

const getProductBySlug = asyncHandler(async (req, res) => {
  const { slug } = req.params;

  const product = await Product.findOne({ slug })
    .populate("categories", "name _id")
    .populate("color", "title _id")
    .populate("size", "name value _id");

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }

  res.status(200).json({
    // categories: {
    //   _id: product.categories?._id,
    //   name: product.categories?.name,
    // },
    categories: product.categories,
    title: product.title,
    longDescription: product.longDescription,
    MRP: product.MRP,
    sellingPrice: product.sellingPrice,
    color: product.color,       
    size: product.size,         
    quantity: product.quantity,
    SKU: product.SKU,
    brand: product.brand,
  });
});

const getRelatedProducts = asyncHandler(async (req, res) => {
  const { slug } = req.params;

  const currentProduct = await Product.findOne({ slug });
  console.log("currentProduct", currentProduct);

  if (!currentProduct) {
    return res.status(404).json({ message: "Product not found" });
  }

  const categoryId = currentProduct.categories;

  const relatedProducts = await Product.find({
    categories: { $in: categoryId },
    _id: { $ne: currentProduct._id },
  })
    .select("title MRP sellingPrice images") 
    .limit(4); 
    console.log(typeof currentProduct._id);

  res.status(200).json(relatedProducts);
});



module.exports = { getProducts,getProductBySlug, getRelatedProducts };
