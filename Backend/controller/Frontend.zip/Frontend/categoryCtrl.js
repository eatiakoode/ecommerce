const Category = require("../../models/categoryModel");
const Product = require("../../models/productModel");
const asyncHandler = require("express-async-handler");
// const getCategoriesWithProductCount = async (req, res) => {
//   try {
//     const categories = await Category.aggregate([
//       {
//         $match: {
//           isActive: true,
//         },
//       },
//       {
//         $lookup: {
//           from: "products", 
//           localField: "_id",
//           foreignField: "category",
//           as: "products",
//         },
//       },
//       {
//         $project: {
//           _id: 1,
//           name: 1,
//           image: 1,
//           productCount: { $size: "$products" },
//         },
//       },
//     ]);

//     res.status(200).json({
//       success: true,
//       data: categories,
//     });
//   } catch (error) {
//     console.error("Error fetching categories with product count:", error);
//     res.status(500).json({
//       success: false,
//       message: "Internal server error",
//     });
//   }
// };
const getCategoriesWithProductCount = async (req, res) => {
  try {
    const categories = await Category.aggregate([
      {
        $match: {
          isActive: true,
        },
      },
      {
        $lookup: {
          from: "products",
          let: { categoryId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: { $in: ["$$categoryId", "$categories"] },
              },
            },
          ],
          as: "products",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          productCount: { $size: "$products" },
        },
      },
    ]);

    res.status(200).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    console.error("Error fetching categories with product count:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};


const getFilteredProducts = asyncHandler(async (req, res) => {
  const products = await Product.find()
    .select("title price images categories")
    .populate("categories", "name")
    .limit(8);
 
  res.status(200).json(products);
});
 


module.exports = {
  getCategoriesWithProductCount,
  getFilteredProducts,
};